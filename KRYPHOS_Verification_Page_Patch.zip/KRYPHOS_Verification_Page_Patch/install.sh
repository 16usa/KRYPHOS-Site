#!/usr/bin/env bash
set -euo pipefail

echo "=== KRYPHOS PUBLIC VERIFICATION PATCH ==="
echo "No restart. No deploy. No SOL spend. No token transfer."

if [ -d "kryphos_burn" ]; then
  PROJECT="kryphos_burn"
else
  PROJECT="."
fi

# Find the app index.html, ignoring build/tooling/vendor output.
INDEX_FILE="$(
  find "$PROJECT" -maxdepth 5 -type f -name "index.html" \
    ! -path "*/node_modules/*" \
    ! -path "*/dist/*" \
    ! -path "*/build/*" \
    ! -path "*/target/*" \
    ! -path "*/.tooling/*" \
    ! -path "*/.git/*" \
    -print 2>/dev/null \
  | while read -r f; do
      if grep -qi '<body' "$f"; then printf '%s\n' "$f"; fi
    done \
  | head -n 1
)"

if [ -z "${INDEX_FILE:-}" ]; then
  echo "ERROR: app index.html was not found."
  echo "Run this and send the result:"
  echo "grep -RIl --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=dist --exclude-dir=build 'Public & Verifiable' \"$PROJECT\" | head -20"
  exit 1
fi

APP_ROOT="$(dirname "$INDEX_FILE")"
# Vite/React normally serves APP_ROOT/public at /
PUBLIC_DIR="$APP_ROOT/public"
mkdir -p "$PUBLIC_DIR"

cp "$(dirname "$0")/files/kryphos-verification-upgrade.js" "$PUBLIC_DIR/kryphos-verification-upgrade.js"
cp "$(dirname "$0")/files/kryphos-verification-upgrade.css" "$PUBLIC_DIR/kryphos-verification-upgrade.css"

if ! grep -q 'kryphos-verification-upgrade.css' "$INDEX_FILE"; then
  cp "$INDEX_FILE" "$INDEX_FILE.bak-kryphos-verification"
  python3 - "$INDEX_FILE" <<'PY'
from pathlib import Path
import sys

p = Path(sys.argv[1])
s = p.read_text()

css = '  <link rel="stylesheet" href="/kryphos-verification-upgrade.css" />\n'
js = '  <script src="/kryphos-verification-upgrade.js" defer></script>\n'

if '</head>' in s:
    s = s.replace('</head>', css + '</head>', 1)
else:
    s = css + s

if '</body>' in s:
    s = s.replace('</body>', js + '</body>', 1)
else:
    s += '\n' + js

p.write_text(s)
PY
fi

echo
echo "Patched:"
echo "  $INDEX_FILE"
echo "  $PUBLIC_DIR/kryphos-verification-upgrade.js"
echo "  $PUBLIC_DIR/kryphos-verification-upgrade.css"
echo
echo "Verification upgrade installed."
echo "No server/system restart was performed."
echo
echo "Git status:"
git status --short 2>/dev/null || true
