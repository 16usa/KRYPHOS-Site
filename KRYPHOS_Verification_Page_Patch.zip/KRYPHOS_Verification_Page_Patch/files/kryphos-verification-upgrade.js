(() => {
  "use strict";

  const CONFIG = {
    programId: "AiAyabtePcmbsA8VSsq4JCvR2qdotL4szqbNggHYvjwS",
    binarySha256: "70a6e471fae667bcef4efc905ea3655b4cc4cd8e1f8c51d48e5f0dbfa044b487",
    binaryBytes: 356920,
    deployer: "JB9NMp1ur1kbVah5rdGz6oEAquNDnAKiZm3ERg5t1c1g",
    rpcUrl: "https://api.mainnet-beta.solana.com",
    explorerBase: "https://solscan.io/account/",
    instructions: ["initialize_vault", "bind_canonical_pool", "burn_next"]
  };

  const state = {
    checkedProgram: false,
    programOnChain: false,
    busy: false
  };

  const clean = (v) => (v || "").replace(/\s+/g, " ").trim();

  function leafByText(text) {
    const target = clean(text);
    const all = document.querySelectorAll("body *:not(script):not(style):not(svg):not(path)");
    for (const el of all) {
      if (el.children.length === 0 && clean(el.textContent) === target) return el;
    }
    return null;
  }

  function findCompactContainer(el, mustContain = [], maxChars = 300) {
    if (!el) return null;
    let cur = el;
    for (let i = 0; i < 7 && cur; i++, cur = cur.parentElement) {
      const t = clean(cur.textContent);
      if (
        t.length <= maxChars &&
        mustContain.every((x) => t.includes(x))
      ) return cur;
    }
    return el.parentElement;
  }

  function replaceLeafExact(oldText, newText, title) {
    const el = leafByText(oldText);
    if (!el) return false;
    el.textContent = newText;
    if (title) el.title = title;
    return true;
  }

  function setTopStatus() {
    const el = leafByText("AWAITING ON-CHAIN ADDRESSES");
    if (!el) return;
    el.textContent = state.programOnChain
      ? "ON-CHAIN PROGRAM VERIFIED"
      : "CODE READY · MAINNET DEPLOYMENT PENDING";
    el.dataset.kvPatched = "1";
  }

  function patchProgramCard() {
    const label = leafByText("PROGRAM");
    if (!label) return;
    const card = findCompactContainer(label, ["PROGRAM", "Not configured"], 220);
    if (!card) return;

    const leaves = card.querySelectorAll("*");
    for (const n of leaves) {
      if (n.children.length === 0 && clean(n.textContent) === "Not configured") {
        n.textContent = CONFIG.programId;
        n.title = CONFIG.programId;
        n.classList.add("kv-address");
      }
      if (n.children.length === 0 && clean(n.textContent) === "OPEN") {
        n.textContent = state.programOnChain ? "VERIFY" : "COPY";
        n.classList.add("kv-proof-action");
        n.onclick = async (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          if (state.programOnChain) {
            window.open(CONFIG.explorerBase + CONFIG.programId, "_blank", "noopener,noreferrer");
          } else {
            try {
              await navigator.clipboard.writeText(CONFIG.programId);
              const prev = n.textContent;
              n.textContent = "COPIED";
              setTimeout(() => (n.textContent = prev), 1200);
            } catch {}
          }
        };
      }
    }
  }

  function patchPlannedNumbers() {
    const mint = leafByText("MINT");
    const mintContainer = findCompactContainer(mint, ["MINT", "Not configured"], 220);
    const total = leafByText("TOTAL SUPPLY");
    if (mintContainer && total) total.textContent = "PLANNED SUPPLY";

    const vault = leafByText("BURN VAULT");
    const vaultContainer = findCompactContainer(vault, ["BURN VAULT", "Not configured"], 220);
    const vb = leafByText("VAULT BALANCE");
    if (vaultContainer && vb) vb.textContent = "PLANNED VAULT";
  }

  function patchUpgradeAuthority() {
    const label = leafByText("Upgrade authority");
    if (!label) return;
    const row = findCompactContainer(label, ["Upgrade authority"], 420);
    if (!row) return;
    for (const n of row.querySelectorAll("*")) {
      if (n.children.length === 0 && clean(n.textContent) === "Waiting for Program ID") {
        n.textContent = "Dedicated deployer configured · on-chain authority pending";
      }
    }
  }

  function makeRow(label, value, status, action) {
    const row = document.createElement("div");
    row.className = "kv-proof-row";

    const meta = document.createElement("div");
    meta.className = "kv-proof-meta";
    const key = document.createElement("div");
    key.className = "kv-proof-key";
    key.textContent = label;
    const val = document.createElement("div");
    val.className = "kv-proof-value";
    val.textContent = value;
    val.title = value;
    meta.append(key, val);

    const right = document.createElement("div");
    right.className = "kv-proof-right";
    const badge = document.createElement("span");
    badge.className = "kv-proof-badge";
    badge.dataset.status = status.toLowerCase();
    badge.textContent = status;
    right.appendChild(badge);

    if (action) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "kv-proof-button";
      btn.textContent = action.label;
      btn.addEventListener("click", action.onClick);
      right.appendChild(btn);
    }

    row.append(meta, right);
    return row;
  }

  function ensureProofPanel() {
    if (document.getElementById("kryphos-proof-panel")) return;

    const anchor = leafByText("Permissionless burn execution");
    if (!anchor) return;

    let host = anchor;
    for (let i = 0; i < 5 && host.parentElement; i++) {
      const t = clean(host.parentElement.textContent);
      if (t.includes("No vault withdrawal path") && t.includes("Permissionless burn execution")) {
        host = host.parentElement;
        break;
      }
      host = host.parentElement;
    }

    const panel = document.createElement("section");
    panel.id = "kryphos-proof-panel";
    panel.innerHTML = `
      <div class="kv-proof-kicker">PUBLIC PROOF</div>
      <div class="kv-proof-heading">Verify the claims yourself</div>
      <div class="kv-proof-intro">
        Every item below points to an on-chain or published technical proof as soon as that proof exists.
        Waiting items stay explicitly marked instead of being presented as live data.
      </div>
      <div class="kv-proof-list"></div>
      <div class="kv-proof-note">
        ON-CHAIN VERIFIED = resolved from Solana mainnet · PROTOCOL = confirmed by published program design / IDL · WAITING = proof does not exist on-chain yet.
      </div>
    `;

    const list = panel.querySelector(".kv-proof-list");

    list.append(
      makeRow(
        "PROGRAM ID",
        CONFIG.programId,
        state.programOnChain ? "ON-CHAIN VERIFIED" : "PREPARED",
        state.programOnChain
          ? {
              label: "OPEN EXPLORER",
              onClick: () => window.open(CONFIG.explorerBase + CONFIG.programId, "_blank", "noopener,noreferrer")
            }
          : {
              label: "COPY ID",
              onClick: () => navigator.clipboard?.writeText(CONFIG.programId)
            }
      ),
      makeRow("PROGRAM BINARY SHA256", CONFIG.binarySha256, "PROTOCOL", {
        label: "COPY HASH",
        onClick: () => navigator.clipboard?.writeText(CONFIG.binarySha256)
      }),
      makeRow(
        "IDL INSTRUCTIONS",
        CONFIG.instructions.join(" · "),
        "PROTOCOL"
      ),
      makeRow("DEPLOY TRANSACTION", "Waiting for Solana mainnet deployment", "WAITING"),
      makeRow("BURN VAULT PDA", "Waiting for initialize_vault", "WAITING"),
      makeRow("MINT", "Not configured", "WAITING"),
      makeRow("LATEST BURN", "Waiting for first completed burn", "WAITING"),
      makeRow("DEPLOYER / FEE PAYER", CONFIG.deployer, "PREPARED", {
        label: "COPY",
        onClick: () => navigator.clipboard?.writeText(CONFIG.deployer)
      })
    );

    host.insertAdjacentElement("afterend", panel);
  }

  async function checkProgramOnChain() {
    if (state.checkedProgram) return;
    state.checkedProgram = true;
    try {
      const res = await fetch(CONFIG.rpcUrl, {
        method: "POST",
        headers: {"content-type": "application/json"},
        body: JSON.stringify({
          jsonrpc: "2.0",
          id: 1,
          method: "getAccountInfo",
          params: [CONFIG.programId, {encoding: "base64", commitment: "confirmed"}]
        })
      });
      const json = await res.json();
      state.programOnChain = !!json?.result?.value;
    } catch {
      state.programOnChain = false;
    }
  }

  async function apply() {
    if (state.busy) return;
    state.busy = true;
    try {
      await checkProgramOnChain();
      setTopStatus();
      patchProgramCard();
      patchPlannedNumbers();
      patchUpgradeAuthority();
      ensureProofPanel();
    } finally {
      state.busy = false;
    }
  }

  let timer = null;
  const schedule = () => {
    clearTimeout(timer);
    timer = setTimeout(apply, 100);
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", apply, {once: true});
  } else {
    apply();
  }

  new MutationObserver(schedule).observe(document.documentElement, {
    subtree: true,
    childList: true
  });

  // Public hook for later on-chain values after deploy.
  window.KRYPHOS_VERIFICATION = {
    config: CONFIG,
    refresh: () => {
      state.checkedProgram = false;
      return apply();
    }
  };
})();
