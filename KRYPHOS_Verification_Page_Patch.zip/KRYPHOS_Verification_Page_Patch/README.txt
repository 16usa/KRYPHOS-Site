KRYPHOS Public Verification Page Patch

What it changes
- Keeps pre-deploy claims honest: planned supply/vault are labelled as planned while mint/vault are not configured.
- Shows Program ID as PREPARED until it actually exists on Solana mainnet.
- Adds a public Proof / Verification section.
- Adds copy / explorer actions for verifiable items.
- Marks deploy transaction, vault PDA, mint and latest burn as WAITING until real on-chain proof exists.
- Detects Program ID on Solana mainnet through read-only JSON-RPC when browser access is available.
- Does not deploy, spend SOL, transfer tokens or restart the project.

Install from the current Replit workspace:
  unzip -o KRYPHOS_Verification_Page_Patch.zip -d /tmp/kryphos-verification && bash /tmp/kryphos-verification/KRYPHOS_Verification_Page_Patch/install.sh

Then review git status and push:
  git add -A && git commit -m "Add public on-chain verification proof layer" && git push

You restart/reload the project manually from Replit.
