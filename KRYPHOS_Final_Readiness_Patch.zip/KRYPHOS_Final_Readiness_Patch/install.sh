#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -f "./scripts/env.sh" && -f "./Anchor.toml" && -d "./programs/kryphos_burn" ]]; then
  ROOT="$(pwd)"
elif [[ -f "./kryphos_burn/scripts/env.sh" && -f "./kryphos_burn/Anchor.toml" ]]; then
  ROOT="$(pwd)/kryphos_burn"
elif [[ -f "/home/runner/workspace/kryphos_burn/scripts/env.sh" ]]; then
  ROOT="/home/runner/workspace/kryphos_burn"
else
  echo "ERROR: Cannot find kryphos_burn project."
  exit 1
fi

echo "=== KRYPHOS FINAL READINESS PATCH ==="
echo "Project: $ROOT"
echo "No deploy. No SOL spend. No token transfer. No restart."
echo

BACKUP="$ROOT/.patch_backups/final-readiness"
mkdir -p "$BACKUP/scripts"

for F in \
  scripts/build.sh \
  scripts/deploy.sh \
  scripts/lib.mjs \
  scripts/initialize-vault.mjs \
  scripts/sync-site-config.mjs \
  package.json
do
  if [[ -f "$ROOT/$F" ]]; then
    mkdir -p "$BACKUP/$(dirname "$F")"
    cp "$ROOT/$F" "$BACKUP/$F"
  fi
done

cp "$HERE/files/scripts/build.sh" "$ROOT/scripts/build.sh"
cp "$HERE/files/scripts/deploy.sh" "$ROOT/scripts/deploy.sh"
cp "$HERE/files/scripts/lib.mjs" "$ROOT/scripts/lib.mjs"
cp "$HERE/files/scripts/initialize-vault.mjs" "$ROOT/scripts/initialize-vault.mjs"
cp "$HERE/files/scripts/sync-site-config.mjs" "$ROOT/scripts/sync-site-config.mjs"
cp "$HERE/files/scripts/mainnet-readiness.mjs" "$ROOT/scripts/mainnet-readiness.mjs"
cp "$HERE/files/package.json" "$ROOT/package.json"

chmod +x "$ROOT/scripts/build.sh" "$ROOT/scripts/deploy.sh"

cd "$ROOT"

echo "=== SYNTAX ==="
node --check scripts/mainnet-readiness.mjs
node --check scripts/lib.mjs
node --check scripts/initialize-vault.mjs
node --check scripts/sync-site-config.mjs
bash -n scripts/build.sh
bash -n scripts/deploy.sh
echo "Syntax: OK"

echo
echo "=== GIT SAFETY ==="
grep -qxF ".secrets/" .gitignore || echo ".secrets/" >> .gitignore
git check-ignore -q .secrets/deployer.json || {
  echo "ERROR: .secrets/deployer.json is not gitignored."
  exit 1
}
echo "Secrets: ignored"

echo
echo "=== READINESS (READ ONLY) ==="
source scripts/env.sh
node scripts/mainnet-readiness.mjs

echo
echo "=== DIFF CHECK ==="
git diff --check -- \
  .gitignore \
  scripts/build.sh \
  scripts/deploy.sh \
  scripts/mainnet-readiness.mjs \
  scripts/lib.mjs \
  scripts/initialize-vault.mjs \
  scripts/sync-site-config.mjs \
  package.json

echo
echo "=== PATCHED FILES ==="
git status --short -- \
  .gitignore \
  scripts/build.sh \
  scripts/deploy.sh \
  scripts/mainnet-readiness.mjs \
  scripts/lib.mjs \
  scripts/initialize-vault.mjs \
  scripts/sync-site-config.mjs \
  package.json

echo
echo "PATCH INSTALLED AND VERIFIED."
echo "Nothing was deployed and no funds/tokens were moved."
