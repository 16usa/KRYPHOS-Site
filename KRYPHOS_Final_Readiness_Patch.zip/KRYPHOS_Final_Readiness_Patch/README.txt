KRYPHOS Final Readiness Patch

Purpose
-------
Prepares KRYPhOS for a later mainnet launch without spending SOL and without moving tokens.

This patch:
- Makes build.sh preserve the already-fixed Cargo.lock.
- Makes deploy.sh use the dedicated deployer and fixed Program ID.
- Adds scripts/mainnet-readiness.mjs (read-only checks).
- Uses the local deployer as the default operational signer when appropriate.
- Requires TOKEN_OWNER_KEYPAIR + explicit LOCK_700M confirmation before mainnet vault initialization.
- Prevents a private SOLANA_RPC_URL from being copied into the public site config.
- Adds npm scripts for safe build/readiness/deploy.
- Never restarts the server.
- Does NOT deploy.
- Does NOT spend SOL.
- Does NOT transfer or burn tokens.

Expected Program ID:
AiAyabtePcmbsA8VSsq4JCvR2qdotL4szqbNggHYvjwS

Install from the existing Replit workspace:
  unzip -o KRYPHOS_Final_Readiness_Patch.zip -d /tmp/kryphos-final
  bash /tmp/kryphos-final/KRYPHOS_Final_Readiness_Patch/install.sh

After successful verification, commit only the patched files:
  cd /home/runner/workspace/kryphos_burn
  git add .gitignore package.json scripts/build.sh scripts/deploy.sh scripts/lib.mjs scripts/initialize-vault.mjs scripts/sync-site-config.mjs scripts/mainnet-readiness.mjs
  git commit -m "Prepare KRYPhOS mainnet launch flow"
  git push

No restart is included.
